#!/bin/env sh

function netns() {
  sudo ip netns exec netns1 ${@}
}

# Usage:
# netns <mycommand_parameter-1> <mycommand_parameter-2> etc...
