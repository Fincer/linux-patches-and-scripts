/*
 * Haguichi, a graphical frontend for Hamachi.
 * Copyright © 2007-2015 Stephen Brandt <stephen@stephenbrandt.com>
 * 
 * Haguichi is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published
 * by the Free Software Foundation; either version 2 of the License,
 * or (at your option) any later version.
 * 
 * Haguichi is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with Haguichi; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

using Gtk;
using System;
using System.Collections;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;


public static class Hamachi
{
    
    public  const  string DataPath        = "/var/lib/logmein-hamachi";
    public  static int    MajorVersion;
    public  static string Version         = "";
    public  static bool   VpnAliasCapable = false;
    public  static bool   IpModeCapable   = false;
    public  static string IpVersion       = "IPv4";
    public  static string lastInfo        = "";
    private static string Service;
    private static Random random;
    
    
    public static void Init ()
    {
        
        GetInfo ();
        MajorVersion = DetermineVersionAndCapabilities ();
        Service = DetermineService ();
        
    }
    
    
    public static int DetermineVersionAndCapabilities ()
    {
        
        if ( Config.Settings.DemoMode )
        {
            Version = "2.1.0.136";
            VpnAliasCapable = true;
            IpModeCapable = true;
            return 2;
        }
        
        if ( !Command.Exists ( "hamachi" ) )
        {
            return 0;
        }
        
        string output = Command.ReturnOutput ( "hamachi", "-h" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.DetermineVersionAndCapabilities", output );
        
        if ( ( output == "timeout" ) ||
             ( output == "error" ) )
        {
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.DetermineVersionAndCapabilities", "Timeout or error" );
            return 0;
        }
        
        if ( output.StartsWith ( "LogMeIn Hamachi, a zero-config virtual private networking utility" ) )
        {
            Version = Retrieve ( lastInfo, "version" );
            
            if ( Version == "" ) // Version has not been retreived from info, go extract from help
            {
                Version = new Regex ( "LogMeIn Hamachi, a zero-config virtual private networking utility, ver (.+)" ).Match ( output ).Groups[1].ToString ();
            }
            
            if ( output.Contains ( "vpn-alias" ) ) // Since version 2.1.0.68
            {
                VpnAliasCapable = true;
                Debug.Log ( Debug.Domain.Hamachi, "Hamachi.DetermineVersionAndCapabilities", "VPN alias capable" );
            }
            if ( output.Contains ( "set-ip-mode" ) ) // Since version 2.1.0.17
            {
                IpModeCapable = true;
                Debug.Log ( Debug.Domain.Hamachi, "Hamachi.DetermineVersionAndCapabilities", "IP mode capable" );
            }
            
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.DetermineVersionAndCapabilities", "LogMeIn Hamachi " + Version + " detected" );
            return 2;
        }
        
        if ( ( output.StartsWith ( "Hamachi, a zero-config virtual private networking utility" ) ) ||
             ( output == "" ) )
        {
            Version = "0.9.9.9-20";
            
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.DetermineVersionAndCapabilities", "Hamachi " + Version + " detected" );
            return 1;
        }
        
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.DetermineVersionAndCapabilities", "Unknown" );
        return -1;
        
    }
    
    
    private static string DetermineService ()
    {
        
        string service = "";
        
        if ( Command.Exists ( "systemctl" ) )
        {
            service = "systemctl {0} logmein-hamachi"; // systemd
        }
        else if ( Command.Exists ( "service" ) )
        {
            service = "service logmein-hamachi {0}"; // Upstart
        }
        else if ( File.Exists ( "/etc/init.d/logmein-hamachi" ) )
        {
            service = "/etc/init.d/logmein-hamachi {0}"; // SysVinit
        }
        else if ( File.Exists ( "/etc/rc.d/logmein-hamachi" ) )
        {
            service = "/etc/rc.d/logmein-hamachi {0}"; // BSD style init
        }
        
        Debug.Log ( Debug.Domain.Environment, "Hamachi.DetermineService", service );
        return service;
        
    }
    
    
    public static string Retrieve ( string output, string nfo )
    {
        
        Regex regex = new Regex ( nfo + "[ ]*:[ ]+(.+)" );
        
        return regex.Match ( output ).Groups[1].ToString ();
        
    }
    
    
    public static void Configure ()
    {
        
        string output = Command.ReturnOutput ( Command.Sudo, Command.SudoArgs + Command.SudoStart + "bash -c \"echo \'Ipc.User      " + System.Environment.UserName + "\' >> " + DataPath + "/h2-engine-override.cfg; " + String.Format ( Service, "restart" ) + "; sleep 1\"" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Configure", output );
        
    }
    
    
    public static string Start ()
    {
        
        string output = Command.ReturnOutput ( Command.Sudo, Command.SudoArgs + Command.SudoStart + String.Format ( Service, "start" ) );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Start", output );
        
        Thread.Sleep ( 1000 );
        
        return output;
        
    }
    
    
    public static string Login ()
    {
        
        string output = Command.ReturnOutput ( "hamachi", "login" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Login", output );
        
        return output;
    }
    
    
    public static string Logout ()
    {
        
        string output = Command.ReturnOutput ( "hamachi", "logout" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Logout", output );
        
        return output;
        
    }
    
    
    public static string GetAccount ()
    {
        
        if ( Config.Settings.DemoMode )
        {
            return "-";
        }
        
        string output = "";
        
        try
        {
            output = Retrieve ( lastInfo, "lmi account" );
        }
        catch {}
        
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.GetAccount", output );
        
        return output;
        
    }
    
    
    public static string GetClientId ()
    {
        
        if ( Config.Settings.DemoMode )
        {
            return "090-123-456";
        }
        
        string output = "";
        
        try
        {
            output = Retrieve ( lastInfo, "client id" );
        }
        catch {}
        
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.GetClientId", output );
        
        return output;
        
    }
    
    
    public static string [] GetAddress ()
    {
        
        if ( Config.Settings.DemoMode )
        {
            IpVersion = "Both";
            return new string [] { "25.123.456.78", "2620:9b::56d:f78e" };
        }
        
        string [] output = new string [] { "", "" };
        
        if ( Hamachi.IpModeCapable )
        {
            try
            {
                string rawOuput = Retrieve ( lastInfo, "address" );
                
                Regex regex = new Regex ( @"^(?<ipv4>[0-9\.]{7,15})?[ ]*(?<ipv6>[0-9a-z\:]+)?$" );
                string IPv4 = regex.Match ( rawOuput ).Groups["ipv4"].ToString ();
                string IPv6 = regex.Match ( rawOuput ).Groups["ipv6"].ToString ();
                
                if ( ( IPv4 != "" ) &&
                     ( IPv6 != "" ) )
                {
                    IpVersion = "Both";
                }
                else if ( IPv4 != "" )
                {
                    IpVersion = "IPv4";
                }
                else if ( IPv6 != "" )
                {
                    IpVersion = "IPv6";
                }
                
                output [0] = IPv4;
                output [1] = IPv6;
            }
            catch {}
        }
        else
        {
            try
            {
                output [0] = Retrieve ( lastInfo, "address" );
            }
            catch {}
        }
        
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.GetAddress", "IPv4: " + output [0] );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.GetAddress", "IPv6: " + output [1] );
        
        return output;
        
    }
    
    
    public static string GetInfo ()
    {
        
        if ( ( !Config.Settings.DemoMode ) &&
             ( Command.Exists ( "hamachi" ) ) )
        {
            lastInfo = Command.ReturnOutput ( "hamachi", "" );
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.GetInfo", lastInfo );
        }
        
        return lastInfo;
        
    }
    
    
    public static bool GoOnline ( Network network )
    {
        
        bool success = true;
        
        if ( !Config.Settings.DemoMode )
        {
            string output = Command.ReturnOutput ( "hamachi", "go-online \"" + Utilities.CleanString ( network.Id ) + "\"" );
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.GoOnline", output );
            
            if ( ( output.Contains ( ".. failed" ) ) &&
                 ( !output.Contains ( ".. failed, already online" ) ) )
            {
                success = false;
                
                string heading = String.Format ( TextStrings.failedGoOnlineHeading, network.Name );
                string message = TextStrings.seeOutput;
                
                Application.Invoke ( delegate
                {
                    new Dialogs.Message ( Haguichi.mainWindow.ReturnWindow (), heading, message, "Error", output );
                });
            }
        }
        
        return success;
        
    }
    
    
    public static bool GoOffline ( Network network )
    {
        
        bool success = true;
        
        if ( !Config.Settings.DemoMode )
        {
            string output = Command.ReturnOutput ( "hamachi", "go-offline \"" + Utilities.CleanString ( network.Id ) + "\"" );
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.GoOffline", output );
            
            if ( ( output.Contains ( ".. failed" ) ) &&
                 ( !output.Contains ( ".. failed, already offline" ) ) )
            {
                success = false;
                
                string heading = String.Format ( TextStrings.failedGoOfflineHeading, network.Name );
                string message = TextStrings.seeOutput;
                
                Application.Invoke ( delegate
                {
                    new Dialogs.Message ( Haguichi.mainWindow.ReturnWindow (), heading, message, "Error", output );
                });
            }
        }
        
        return success;
        
    }
    
    
    public static void Delete ( Network network )
    {
        
        string output = Command.ReturnOutput ( "hamachi", "delete \"" + Utilities.CleanString ( network.Id ) + "\"" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Delete", output );

        if ( output.Contains ( ".. failed" ) )
        {
            string heading = String.Format ( TextStrings.failedDeleteNetworkHeading, network.Name );
            string message = TextStrings.seeOutput;
            
            Application.Invoke ( delegate
            {
                new Dialogs.Message ( Haguichi.mainWindow.ReturnWindow (), heading, message, "Error", output );
            });
        }
        
    }
    
    
    public static void Leave ( Network network )
    {
        
        string output = Command.ReturnOutput ( "hamachi", "leave \"" + Utilities.CleanString ( network.Id ) + "\"" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Leave", output );
        
        if ( output.Contains ( ".. failed" ) )
        {
            string heading = String.Format ( TextStrings.failedLeaveNetworkHeading, network.Name );
            string message = TextStrings.seeOutput;
            
            Application.Invoke ( delegate
            {
                new Dialogs.Message ( Haguichi.mainWindow.ReturnWindow (), heading, message, "Error", output );
            });
        }
        
    }
    
    
    public static void Approve ( Member member )
    {
        
        string output = Command.ReturnOutput ( "hamachi", "approve \"" + Utilities.CleanString ( member.Network ) + "\" " + member.ClientId );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Approve", output );
        
    }
    
    
    public static void Reject ( Member member )
    {
        
        string output = Command.ReturnOutput ( "hamachi", "reject \"" + Utilities.CleanString ( member.Network ) + "\" " + member.ClientId );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Reject", output );
        
    }
    
    
    public static void Evict ( Member member )
    {
        
        string output = Command.ReturnOutput ( "hamachi", "evict \"" + Utilities.CleanString ( member.Network ) + "\" " + member.ClientId );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Evict", output );

        if ( output.Contains ( ".. failed" ) )
        {
            string heading = String.Format ( TextStrings.failedEvictMemberHeading, member.Nick );
            string message = TextStrings.seeOutput;
            
            Application.Invoke ( delegate
            {
                new Dialogs.Message ( Haguichi.mainWindow.ReturnWindow (), heading, message, "Error", output );
            });
        }
        
    }
    
    
    private static string GetList ()
    {
        
        string output = Command.ReturnOutput ( "hamachi", "list" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.GetList", "\n" + output );
        
        return output;
        
    }
    
    
    public static string RandomAddress ()
    {
        
        string address  = "25.";
               address += random.Next ( 1, 255 );
               address += ".";
               address += random.Next ( 1, 255 );
               address += ".";
               address += random.Next ( 1, 255 );
        
        return address;
        
    }
    
    
    public static string RandomClientId ()
    {
        
        string id  = "0";
               id += random.Next ( 80, 99 );
               id += "-";
               id += random.Next ( 100, 999 );
               id += "-";
               id += random.Next ( 100, 999 );
        
        return id;
        
    }
    
    
    public static string RandomNetworkId ()
    {
        
        string id  = "0";
               id += random.Next ( 40, 45 );
               id += "-";
               id += random.Next ( 100, 999 );
               id += "-";
               id += random.Next ( 100, 999 );
        
        return id;
        
    }
    
    
    public static ArrayList ReturnList ()
    {
        
        ArrayList networks = new ArrayList ();
        string output = "";
        
        if ( Config.Settings.DemoMode )
        {
            if ( Config.Settings.DemoListPath != null )
            {
                output = Command.ReturnOutput ( "cat", Config.Settings.DemoListPath );
            }
            else
            {
                random = new Random ();
                
                output += " * [Artwork]\n";
                output += "       " + RandomClientId () + "   Lapo                       " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     * 090-736-821   ztefn                      " + RandomAddress () + "  alias: not set        2146:0d::987:a654    direct\n";
                output += "   [Bug Hunters]  capacity: 4/5,   [192.168.155.24/24]  subscription type: Free, owner: This computer\n";
                output += "     * " + RandomClientId () + "   Conrad                     192.168.155.20  alias: not set                             via relay\n";
                output += "     * " + RandomClientId () + "   Eduardo                    192.168.155.21  alias: not set                             direct\n";
                output += "       " + RandomClientId () + "   war59312                   192.168.155.22\n";
                output += "     ? " + RandomClientId () + " \n";
                output += "       You are approaching your member limit and may soon have to upgrade your network.\n";
                output += " * [" + RandomNetworkId () + "]  Development  capacity: 2/32, subscription type: Standard, owner: ztefn (090-736-821)\n";
                output += "     * 090-736-821   ztefn                      " + RandomAddress () + "  alias: not set        2146:0d::987:a654    direct\n";
                output += "   [" + RandomNetworkId () + "]Packaging  capacity: 4/256, subscription type: Premium, owner: Andrew (094-409-761)\n";
                output += "     * " + RandomClientId () + "   AndreasBWagner             " + RandomAddress () + "  alias: not set                             via relay\n";
                output += "     * 094-409-761   Andrew                     " + RandomAddress () + "  alias: not set                             direct\n";
                output += "       " + RandomClientId () + "   etamPL                     " + RandomAddress () + "\n";
                output += " * [" + RandomNetworkId () + "]Translators  capacity: 15/256, subscription type: Multi-network, owner: translators@haguichi.net\n";
                output += "     x " + RandomClientId () + "   Aytunç                     " + RandomAddress () + "\n";
                output += "     * " + RandomClientId () + "   Brbla                      " + RandomAddress () + "  alias: not set                             via relay\n";
                output += "       " + RandomClientId () + "   Daniel                     " + RandomAddress () + "\n";
                output += "     ! " + RandomClientId () + "   dimitrov                   " + RandomAddress () + "  alias: not set                             IP protocol mismatch between you and peer\n";
                output += "     * " + RandomClientId () + "   enricog                    " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     * " + RandomClientId () + "   Fedik                      " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     * " + RandomClientId () + "   galamarv                   " + RandomAddress () + "  alias: not set                             via relay\n";
                output += "     * " + RandomClientId () + "   HeliosReds                 " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     ! " + RandomClientId () + "   jmb_kz                     " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     * " + RandomClientId () + "   Ḷḷumex03                   " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     * " + RandomClientId () + "   Raven46                    " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     * " + RandomClientId () + "   Rodrigo                    " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     ! " + RandomClientId () + "   scrawl                     " + RandomAddress () + "  alias: 25.353.432.28  2620:9b::753:b470    direct      UDP  170.45.240.141:43667  This address is also used by another peer\n";
                output += "       " + RandomClientId () + "   Sergey                     " + RandomAddress () + "\n";
                output += "     x " + RandomClientId () + "   Soker                      " + RandomAddress () + "\n";
                output += "     * " + RandomClientId () + "   Zdeněk                     " + RandomAddress () + "  alias: not set                             direct\n";
                output += "     * " + RandomClientId () + "   ztefn                      " + RandomAddress () + "  alias: not set        2146:0d::987:a654    direct\n";
            }
        }
        else
        {
            output = GetList ();
        }
        
        string [] split = output.Split ( Environment.NewLine.ToCharArray () );
        string curNetworkId = "";
        
        Regex networkRegex          = new Regex ( @"^ (?<status>.{1}) \[(?<id>.+?)\][ ]*(?<name>.*?)[ ]*(capacity: [0-9]+/(?<capacity>[0-9]+),)?[ ]*(\[(?<subnet>[0-9\./]{9,19})\])?[ ]*( subscription type: (?<subscription>[^,]+),)?( owner: (?<owner>.*))?$" );
        Regex normalMemberRegex     = new Regex ( @"^     (?<status>.{1}) (?<id>[0-9-]{11})[ ]+(?<name>.*?)[ ]*(?<ipv4>[0-9\.]{7,15})?[ ]*(alias: (?<alias>[0-9\.]{7,15}|not set))?[ ]*(?<ipv6>[0-9a-f\:]+\:[0-9a-f\:]+)?[ ]*(?<connection>direct|via relay|via server)?[ ]*(?<transport>UDP|TCP)?[ ]*(?<tunnel>[0-9\.]+\:[0-9]+)?[ ]*(?<message>[ a-zA-Z]+)?$" );
        Regex unapprovedMemberRegex = new Regex ( @"^     \? (?<id>[0-9-]{11})[ ]*$" );
        
        foreach ( string s in split )
        {
           
            if ( s.Length > 5 ) // Check string for minimum chars
            {
            
                if ( s.IndexOf ( "[" ) == 3 ) // Line contains network
                {
                    
                    Match match = networkRegex.Match ( s );
                    
                    Status status = new Status ( match.Groups["status"].ToString () );
                    string id     = match.Groups["id"].ToString ();
                    string name   = id;
                    string owner  = match.Groups["owner"].ToString ();
                    
                    int capacity;
                    Int32.TryParse ( match.Groups["capacity"].ToString (), out capacity );
                    
                    try
                    {
                        name = match.Groups["name"].ToString ().TrimEnd ();
                        
                        if ( name.Length == 0 )
                        {
                            name = id;
                        }
                    }
                    catch
                    {
                        // No name
                    }

                    Network network = new Network ( status, id, name, owner, capacity );
                    networks.Add ( network );
                    
                    curNetworkId = id;
                    
                }
                else if ( s.IndexOf ( "?" ) == 5 ) // Line contains unapproved member
                {
                    
                    Match match = unapprovedMemberRegex.Match ( s );
                    
                    Status status = new Status ( "?" );
                    string client = match.Groups["id"].ToString ();
                    string nick   = TextStrings.unknown;
                    
                    Member member = new Member ( status, curNetworkId, "", "", nick, client, "" );
                    
                    foreach ( Network network in networks )
                    {
                        if ( network.Id == curNetworkId )
                        {
                            network.AddMember ( member );
                        }
                    }
                    
                }
                else if ( s.IndexOf ( "-" ) == 10 ) // Line contains normal member
                {
                    
                    Match match = normalMemberRegex.Match ( s );
                    
                    string connection = match.Groups["connection"].ToString ();
                    string client     = match.Groups["id"].ToString ();
                    string ipv4       = match.Groups["ipv4"].ToString ();
                    string ipv6       = match.Groups["ipv6"].ToString ();
                    string nick       = match.Groups["name"].ToString ();
                    string alias      = match.Groups["alias"].ToString ();
                    string tunnel     = match.Groups["tunnel"].ToString ();
                    string message    = match.Groups["message"].ToString ();
                    
                    Status status = new Status ( match.Groups["status"].ToString (), connection, message );
                    
                    if ( ( nick == "" ) ||
                         ( nick == "anonymous" ) )
                    {
                        nick = TextStrings.anonymous;
                    }
                    
                    if ( alias.Contains ( "." ) )
                    {
                        ipv4 = alias;
                        ipv6 = ""; // IPv6 address doesn't work when the alias is set, therefore clearing it
                    }
                    
                    Member member = new Member ( status, curNetworkId, ipv4, ipv6, nick, client, tunnel );
                    
                    foreach ( Network network in networks )
                    {
                        if ( network.Id == curNetworkId )
                        {
                            network.AddMember ( member );
                        }
                    }
                    
                }
                
            }
            
        }
        
        return networks;
        
    }
    
    
    public static string SetNick ( string nick )
    {
        
        string output = "";
        
        if ( ( !Config.Settings.DemoMode ) &&
             ( Controller.lastStatus >= 6 ) )
        {
            output = Command.ReturnOutput ( "hamachi", "set-nick \"" + Utilities.CleanString ( nick ) + "\"" );
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.SetNick", output );
        }
        
        return output;
        
    }
    
    
    public static string SetProtocol ( string protocol )
    {
        
        string output = "";
        
        if ( !Config.Settings.DemoMode )
        {
            output = Command.ReturnOutput ( "hamachi", "set-ip-mode \"" + protocol + "\"" );
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.SetProtocol", output );
        }
        
        return output;
        
    }
    
    
    public static string Attach ( string accountId, bool withNetworks )
    {
        
        string output  = "";
        string command = "attach";
        
        if ( withNetworks )
        {
            command += "-net";
        }
        
        output = Command.ReturnOutput ( "hamachi", command + " \"" + Utilities.CleanString ( accountId ) + "\"" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.Attach", output );
        
        return output;
        
    }
    
    
    public static string JoinNetwork ( string name, string password )
    {
        
        string output = Command.ReturnOutput ( "hamachi", "do-join \"" + Utilities.CleanString ( name ) + "\" \"" + Utilities.CleanString ( password ) + "\"" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.JoinNetwork", output );
        
        return output;
        
    }
    
    
    public static string SetAccess ( string networkId, string locking, string approve )
    {
        
        string output = "";
        
        if ( !Config.Settings.DemoMode )
        {
            output = Command.ReturnOutput ( "hamachi", "set-access \"" + Utilities.CleanString ( networkId ) + "\" " + locking + " " + approve );
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.SetAccess", output );
        }
        
        return output;
        
    }
    
    
    public static string SetPassword ( string networkId, string password )
    {
        
        string output = "";
        
        if ( !Config.Settings.DemoMode )
        {
            output = Command.ReturnOutput ( "hamachi", "set-pass \"" + Utilities.CleanString ( networkId ) + "\" \"" + Utilities.CleanString ( password ) + "\"" );
            Debug.Log ( Debug.Domain.Hamachi, "Hamachi.SetPassword", output );
        }
        
        return output;
        
    }
    
    
    public static string CreateNetwork ( string name, string password )
    {
        
        string output = Command.ReturnOutput ( "hamachi", "create \"" + Utilities.CleanString ( name ) + "\" \"" + Utilities.CleanString ( password ) + "\"" );
        Debug.Log ( Debug.Domain.Hamachi, "Hamachi.CreateNetwork", output );
        
        return output;
        
    }
    
    
    public static void SaveBackup ( string filename )
    {
        
        string output = Command.ReturnOutput ( "tar", "-cavPf '" + filename + "' " + Hamachi.DataPath );
        Debug.Log ( Debug.Domain.Info, "Hamachi.SaveBackup", output );
        
    }
    
    
    public static void RestoreBackup ( string filename )
    {
        
        string output = Command.ReturnOutput ( "tar", "-tvf '" + filename + "'" );
        Debug.Log ( Debug.Domain.Info, "Hamachi.RestoreBackup", "Listing archive contents...\n" + output );
        
        if ( output.Contains ( Hamachi.DataPath ) )
        {
            GlobalEvents.StopHamachi ();
            
            output = Command.ReturnOutput ( Command.Sudo, Command.SudoArgs + Command.SudoStart + "bash -c \"" + String.Format ( Service, "stop" ) + "; sleep 1; rm " + Hamachi.DataPath + "/*; tar -xavf '" + filename + "' -C /; " + String.Format ( Service, "start" ) + "; sleep 1\"" );
            Debug.Log ( Debug.Domain.Info, "Hamachi.RestoreBackup", output );
            
            Controller.Init ();
        }
        else
        {
            Debug.Log ( Debug.Domain.Info, "Hamachi.RestoreBackup", "Archive doesn't contain " + Hamachi.DataPath );
            new Dialogs.Message ( Haguichi.mainWindow.ReturnWindow (), TextStrings.configRestoreErrorTitle, TextStrings.configRestoreErrorMessage, "Error", null );
        }
        
    }
    
}
