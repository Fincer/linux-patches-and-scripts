//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by zsnes.rc
//
#define IDI_ICON1                       101
#define IDD_NO_CONNECT                  118
#define IDD_LOADING                     119
#define IDD_USERPASS                    120
#define IDC_DESTRUCT                    1078
#define IDC_PARTDONE                    1079
#define IDC_PROGRESS1                   1080
#define IDC_USER                        1081
#define IDC_PASS                        1082
#define IDC_EDITUSER                    1083
#define IDC_EDITPASS                    1084

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        121
#define _APS_NEXT_COMMAND_VALUE         40038
#define _APS_NEXT_CONTROL_VALUE         1084
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
